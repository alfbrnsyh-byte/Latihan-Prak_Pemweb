<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="icon" href="assets/icon.png" />
  <link rel="stylesheet" href="css/style.css" />
  <title>CatShop | Login</title>
 </head>
 <body>
  <div class="auth-page">
   <div class="login-box">
    <div class="auth-logo">CATSHOP</div>
    <h2>Welcome Back !</h2>
    <form action="login-proses.php" method="post">
     <label>Username</label>
     <input type="text" name="username">
     <label>Password</label>
     <input type="password" name="password">
     <button type="submit" class="auth-button" name="login">Login</button>
    </form>
    <p class="account-text">Don't have an account? <a href="register.php">Register</a></p>
   </div>
  </div>
 </body>
</html>

<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="icon" href="assets/icon.png" />
  <link rel="stylesheet" href="css/style.css" />
  <title>CatShop | Register</title>
 </head>
 <body>
  <div class="auth-page">
   <div class="register-box">
    <div class="auth-logo">CATSHOP</div>
    <h2>Create Account</h2>
    <form action="register-proses.php" method="post">
     <label>Username</label>
     <input type="text" name="username">
     <label>Email</label>
     <input type="email" name="email">
     <label>Password</label>
     <input type="password" name="password">
     <button type="submit" class="auth-button" name="register">Register</button>
    </form>
    <p class="account-text">Already have an account? <a href="login.php">Login</a></p>
   </div>
  </div>
 </body>
</html>
